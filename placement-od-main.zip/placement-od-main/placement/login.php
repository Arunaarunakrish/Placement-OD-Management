<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>login page</title>
  <style>
  body {
    font-size:30px;
    font-family: "Times New Roman", Times, serif;
    background-image: url(back.jpeg);
    background-size: cover;
    background-position:cover;
    background-repeat: no-repeat;
  }

  button {
    font-size:20px;
    background-color: skyblue;
    width: 30%;
    color: black;
    padding: 15px;
    margin: 10px 0px;
  }
</style>
</head>
        <body>
	<center><h1>
   STUDENT PLACEMENT MANAGEMENT
    </h1>
<br><a href="Student login.php"><button>Student </button></br>
<br><a href="Tutor login.php"><button>Tutor </button></a></br>
<br><a href="Hod login.php"><button>Hod </button></a></center></br> 
        </body>
</html>+
