<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Student Login </title>
  <style>
    body {
    color:black;
    font-size:25px;
    background-color:light yellow;
    background-size: cover;
    background-position: cover;
    background-repeat: no-repeat;
  }
 
button {  
       font-size:20px;   
       width: 30%;  
        color: black;   
        padding: 15px ;   
        margin: 10px 0px;
        font-family: "Times New Roman", Times, serif;      
         }    
		 a{
			 text-decoration:red;
		 }
  </style>
</head>
<body>
  <center><h1>FORMS</h1>
  <br> <button><a href="od form.php">OD FORM</a></button></br>
  <br> <button><a href="feedback form.php">FEEDBACK FORM</a></button></br>
  <br> <button ><a href="student login.php">Go Back</a></button></br></center>
</body>
</html>
